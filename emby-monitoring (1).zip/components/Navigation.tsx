"use client"

import Link from "next/link"
import { BarChart3 } from "lucide-react"

interface NavigationProps {
  apps: any
  activeTab: string
  onTabChange: (tab: string) => void
}

export function Navigation({ apps, activeTab, onTabChange }: NavigationProps) {
  return (
    <nav className="bg-gray-900 flex overflow-x-auto border-b border-yellow-600/30">
      {/* Galleri Photo */}
      <a
        href="https://marlo-movie.com/galerie"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 px-4 py-3 text-sm font-semibold uppercase tracking-wide text-white bg-red-900 hover:bg-red-800 transition-colors whitespace-nowrap"
      >
        <i className="fas fa-images"></i>
        Galleri photo
      </a>

      {/* Onglets dynamiques */}
      {Object.entries(apps).map(([tabId, tabData]: [string, any]) => (
        <button
          key={tabId}
          onClick={() => onTabChange(tabId)}
          className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold uppercase tracking-wide transition-colors whitespace-nowrap border-b-3 ${
            activeTab === tabId
              ? "text-yellow-600 border-yellow-600"
              : "text-white border-transparent hover:bg-gray-800"
          }`}
        >
          <i className={`fas fa-${tabData.icon}`}></i>
          {tabData.name}
        </button>
      ))}

      {/* Status Emby */}
      <a
        href="https://marlo-movie.com/groupe"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 px-4 py-3 text-sm font-semibold uppercase tracking-wide text-white hover:bg-gray-800 transition-colors whitespace-nowrap"
      >
        <i className="fas fa-chart-line"></i>
        Status Emby
      </a>

      {/* Statistiques */}
      <Link
        href="/statistics"
        className="flex items-center gap-2 px-4 py-3 text-sm font-semibold uppercase tracking-wide text-white hover:bg-gray-800 transition-colors whitespace-nowrap"
      >
        <BarChart3 className="w-4 h-4" />
        Statistiques
      </Link>

      {/* Demande */}
      <a
        href="https://iptv.marlo-movie.com"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 px-4 py-3 text-sm font-semibold uppercase tracking-wide text-white bg-red-900 hover:bg-red-800 transition-colors whitespace-nowrap ml-auto mr-2"
      >
        <i className="fas fa-tv"></i>
        Demande
      </a>
    </nav>
  )
}
