import { Server } from "lucide-react"

interface StatusOverviewProps {
  statuses: Record<string, any>
  totalApps: number
}

export function StatusOverview({ statuses, totalApps }: StatusOverviewProps) {
  const onlineCount = Object.values(statuses).filter((status) => status?.online).length
  const percentage = totalApps > 0 ? (onlineCount / totalApps) * 100 : 0

  return (
    <div className="flex justify-center mb-6">
      <div className="bg-gray-800 border border-yellow-600/30 rounded-lg p-4 flex items-center gap-4">
        <Server className="w-6 h-6 text-yellow-600" />
        <span className="text-white font-medium">
          {onlineCount}/{totalApps} services en ligne
        </span>
        <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
          <div className="h-full bg-green-500 transition-all duration-300" style={{ width: `${percentage}%` }} />
        </div>
      </div>
    </div>
  )
}
