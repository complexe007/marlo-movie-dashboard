import type React from "react"

interface DialogProps {
  children: React.ReactNode
}

const Dialog = ({ children }: DialogProps) => {
  return <div>{children}</div>
}

interface DialogTriggerProps {
  asChild?: boolean
  children: React.ReactNode
}

const DialogTrigger = ({ children }: DialogTriggerProps) => {
  return <div>{children}</div>
}

interface DialogContentProps {
  className?: string
  children: React.ReactNode
}

const DialogContent = ({ className, children }: DialogContentProps) => {
  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center bg-black/50 ${className}`}>
      <div className="max-w-lg w-full mx-4 p-6 rounded-lg">{children}</div>
    </div>
  )
}

interface DialogHeaderProps {
  children: React.ReactNode
}

const DialogHeader = ({ children }: DialogHeaderProps) => {
  return <div className="mb-4">{children}</div>
}

interface DialogTitleProps {
  children: React.ReactNode
}

const DialogTitle = ({ children }: DialogTitleProps) => {
  return <h2 className="text-lg font-semibold">{children}</h2>
}

interface DialogDescriptionProps {
  children: React.ReactNode
}

const DialogDescription = ({ children }: DialogDescriptionProps) => {
  return <p className="text-sm mt-2">{children}</p>
}

interface DialogFooterProps {
  children: React.ReactNode
}

const DialogFooter = ({ children }: DialogFooterProps) => {
  return <div className="flex justify-end gap-2 mt-4">{children}</div>
}

export { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter }
