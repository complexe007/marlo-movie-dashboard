import React from "react"

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {}

const Card = React.forwardRef<HTMLDivElement, CardProps>(({ className, ...props }, ref) => (
  <div
    className={`rounded-lg border bg-card text-card-foreground shadow-sm data-[state=open]:bg-accent data-[state=open]:text-accent-foreground ${className}`}
    {...props}
    ref={ref}
  />
))
Card.displayName = "Card"

interface CardHeaderProps extends React.HTMLAttributes<HTMLDivElement> {}

const CardHeader = React.forwardRef<HTMLDivElement, CardHeaderProps>(({ className, ...props }, ref) => (
  <div className={`flex flex-col space-y-1.5 p-6 ${className}`} {...props} ref={ref} />
))
CardHeader.displayName = "CardHeader"

interface CardTitleProps extends React.HTMLAttributes<HTMLDivElement> {}

const CardTitle = React.forwardRef<HTMLDivElement, CardTitleProps>(({ className, ...props }, ref) => (
  <h3 className={`text-lg font-semibold leading-none tracking-tight ${className}`} {...props} ref={ref} />
))
CardTitle.displayName = "CardTitle"

interface CardDescriptionProps extends React.HTMLAttributes<HTMLDivElement> {}

const CardDescription = React.forwardRef<HTMLDivElement, CardDescriptionProps>(({ className, ...props }, ref) => (
  <p className={`text-sm text-muted-foreground ${className}`} {...props} ref={ref} />
))
CardDescription.displayName = "CardDescription"

interface CardContentProps extends React.HTMLAttributes<HTMLDivElement> {}

const CardContent = React.forwardRef<HTMLDivElement, CardContentProps>(({ className, ...props }, ref) => (
  <div className={`p-6 pt-0 ${className}`} {...props} ref={ref} />
))
CardContent.displayName = "CardContent"

interface CardFooterProps extends React.HTMLAttributes<HTMLDivElement> {}

const CardFooter = React.forwardRef<HTMLDivElement, CardFooterProps>(({ className, ...props }, ref) => (
  <div className={`flex items-center p-6 pt-0 ${className}`} {...props} ref={ref} />
))
CardFooter.displayName = "CardFooter"

interface ButtonProps extends React.HTMLAttributes<HTMLButtonElement> {}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, ...props }, ref) => {
  return (
    <button
      className={`inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 ${
        variant === "outline"
          ? "bg-transparent border border-input hover:bg-accent hover:text-accent-foreground"
          : "bg-primary text-primary-foreground shadow-sm hover:bg-primary/90"
      } ${size === "sm" ? "px-3 py-1.5 text-sm" : size === "lg" ? "px-8 py-3 text-lg" : "px-4 py-2"} ${className}`}
      ref={ref}
      {...props}
    />
  )
})
Button.displayName = "Button"

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {}

const Badge = React.forwardRef<HTMLDivElement, BadgeProps>(({ className, variant, ...props }, ref) => {
  return (
    <div
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none border-transparent ${
        variant === "secondary"
          ? "bg-secondary text-secondary-foreground hover:bg-secondary/80"
          : "bg-primary text-primary-foreground hover:bg-primary/80"
      } ${className}`}
      ref={ref}
      {...props}
    />
  )
})
Badge.displayName = "Badge"

export { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter, Button, Badge }
