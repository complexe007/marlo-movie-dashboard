"use client"

import { useState } from "react"
import { AlertCircle, CheckCircle, Clock } from "lucide-react"

interface AppCardProps {
  app: {
    name: string
    url: string
    logo?: string
    icon?: string
    color: string
    description: string
  }
  status?: {
    online: boolean
    response_time?: number
    error?: boolean
  }
  onClick: () => void
}

export function AppCard({ app, status, onClick }: AppCardProps) {
  const [imageError, setImageError] = useState(false)

  const getIconClass = (appName: string) => {
    const name = appName.toLowerCase()
    if (name.includes("emby")) return "fas fa-server"
    if (name.includes("radarr")) return "fas fa-film"
    if (name.includes("sonarr")) return "fas fa-tv"
    if (name.includes("prowlarr")) return "fas fa-search"
    if (name.includes("transmission")) return "fas fa-download"
    if (name.includes("portainer")) return "fab fa-docker"
    if (name.includes("synology")) return "fas fa-hdd"
    if (name.includes("cpanel")) return "fas fa-server"
    return app.icon ? `fas fa-${app.icon}` : "fas fa-cube"
  }

  return (
    <div
      onClick={onClick}
      className={`relative bg-gray-800 rounded-lg overflow-hidden shadow-lg transition-all duration-300 cursor-pointer hover:transform hover:-translate-y-1 hover:shadow-xl border border-yellow-600/10 hover:border-yellow-600/30 h-48 flex flex-col ${
        status?.online === false ? "opacity-60" : ""
      }`}
    >
      {/* Status Indicator */}
      <div className="absolute top-2 right-2 z-10 bg-black/80 rounded-full px-2 py-1 flex items-center gap-1 text-xs">
        {status?.online === true ? (
          <>
            <CheckCircle className="w-3 h-3 text-green-500" />
            <span className="text-green-500">En ligne</span>
            {status.response_time && <span className="text-orange-400 ml-1">{status.response_time}ms</span>}
          </>
        ) : status?.online === false ? (
          <>
            <AlertCircle className="w-3 h-3 text-red-500" />
            <span className="text-red-500">Hors ligne</span>
          </>
        ) : (
          <>
            <Clock className="w-3 h-3 text-yellow-500" />
            <span className="text-yellow-500">Vérification...</span>
          </>
        )}
      </div>

      {/* App Icon */}
      <div className="h-28 flex items-center justify-center p-4 overflow-hidden" style={{ backgroundColor: app.color }}>
        {app.logo && !imageError ? (
          <img
            src={app.logo || "/placeholder.svg"}
            alt={`${app.name} logo`}
            className="max-w-full max-h-full object-contain transition-transform duration-300 hover:scale-110"
            onError={() => setImageError(true)}
            loading="lazy"
          />
        ) : (
          <i
            className={`${getIconClass(app.name)} text-white text-4xl transition-transform duration-300 hover:scale-110`}
          ></i>
        )}
      </div>

      {/* App Info */}
      <div className="p-3 bg-black/20 flex-1 flex flex-col justify-center text-center">
        <h3 className="font-semibold text-white text-sm mb-1 line-clamp-1">{app.name}</h3>
        <p className="text-gray-300 text-xs line-clamp-2">{app.description}</p>
      </div>
    </div>
  )
}
