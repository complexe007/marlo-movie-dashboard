document.addEventListener("DOMContentLoaded", () => {
  // Fonction de recherche
  const searchInput = document.getElementById("searchInput")
  if (searchInput) {
    searchInput.addEventListener("input", function () {
      const searchTerm = this.value.toLowerCase()
      const appCards = document.querySelectorAll(".app-card")

      appCards.forEach((card) => {
        const appName = card.getAttribute("data-name")
        const appDescription = card.getAttribute("data-description")

        if (appName.includes(searchTerm) || appDescription.includes(searchTerm)) {
          card.style.display = "flex"
        } else {
          card.style.display = "none"
        }
      })
    })
  }

  // Gestion des clics sur les applications
  const appCards = document.querySelectorAll(".app-card")
  appCards.forEach((card) => {
    card.addEventListener("click", function () {
      const appName = this.getAttribute("data-app-name")
      const appUrl = this.getAttribute("data-url")
      const category = getCurrentCategory()

      // Enregistrer le clic
      trackClick(appName, appUrl, category)

      // Ouvrir l'application
      window.open(appUrl, "_blank")
    })

    // Gestion des erreurs de chargement d'images
    const img = card.querySelector(".app-icon img")
    if (img) {
      img.addEventListener("error", function () {
        const appName = card.querySelector(".app-name").textContent
        const iconContainer = this.parentElement

        // Créer une icône par défaut basée sur le nom de l'application
        let iconClass = "fas fa-cube" // Icône par défaut

        // Déterminer l'icône en fonction du nom de l'application
        if (appName.toLowerCase().includes("emby")) iconClass = "fas fa-server"
        else if (appName.toLowerCase().includes("radarr")) iconClass = "fas fa-film"
        else if (appName.toLowerCase().includes("sonarr")) iconClass = "fas fa-tv"
        else if (appName.toLowerCase().includes("prowlarr")) iconClass = "fas fa-search"
        else if (appName.toLowerCase().includes("transmission")) iconClass = "fas fa-download"
        else if (appName.toLowerCase().includes("portainer")) iconClass = "fas fa-docker"
        else if (appName.toLowerCase().includes("synology")) iconClass = "fas fa-hdd"
        else if (appName.toLowerCase().includes("cpanel")) iconClass = "fas fa-server"

        // Remplacer l'image par l'icône
        this.remove()
        const icon = document.createElement("i")
        icon.className = iconClass
        icon.style.color = "white"
        icon.style.fontSize = "48px"
        iconContainer.appendChild(icon)
      })
    }
  })

  // Vérification périodique du statut des services
  setInterval(updateServiceStatuses, 60000) // Toutes les minutes
})

function getCurrentCategory() {
  const url = new URL(window.location.href)
  return url.searchParams.get("tab") || "medias"
}

function trackClick(appName, appUrl, category) {
  fetch("track_click.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      app_name: appName,
      app_url: appUrl,
      category: category,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (!data.success) {
        console.warn("Erreur lors de l'enregistrement du clic:", data.error)
      }
    })
    .catch((error) => {
      console.warn("Erreur lors de l'enregistrement du clic:", error)
    })
}

function updateServiceStatuses() {
  const appCards = document.querySelectorAll(".app-card")

  appCards.forEach((card) => {
    const appUrl = card.getAttribute("data-url")
    if (appUrl) {
      fetch(`check_status.php?url=${encodeURIComponent(appUrl)}`)
        .then((response) => response.json())
        .then((data) => {
          updateStatusIndicator(card, data)
        })
        .catch((error) => {
          console.warn("Erreur lors de la vérification du statut:", error)
        })
    }
  })
}

function updateStatusIndicator(card, status) {
  const indicator = card.querySelector(".status-indicator")
  const statusIcon = indicator.querySelector("i")
  const statusText = indicator.querySelector(".status-text")
  const responseTime = indicator.querySelector(".response-time")

  if (status.online) {
    card.classList.remove("offline")
    card.classList.add("online")
    statusIcon.className = "fas fa-circle status-online"
    statusText.textContent = "En ligne"

    if (status.response_time && responseTime) {
      responseTime.textContent = status.response_time + "ms"
      responseTime.style.display = "inline"
    }
  } else {
    card.classList.remove("online")
    card.classList.add("offline")
    statusIcon.className = "fas fa-circle status-offline"
    statusText.textContent = "Hors ligne"

    if (responseTime) {
      responseTime.style.display = "none"
    }
  }
}
