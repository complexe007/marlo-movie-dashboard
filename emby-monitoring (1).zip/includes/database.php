<?php
function getDatabase() {
    try {
        $pdo = new PDO('sqlite:' . DB_PATH);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        error_log("Erreur de connexion à la base de données: " . $e->getMessage());
        return null;
    }
}

function initDatabase() {
    $pdo = getDatabase();
    if (!$pdo) return false;
    
    try {
        // Table pour les statistiques d'utilisation
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS usage_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                app_name TEXT NOT NULL,
                app_url TEXT NOT NULL,
                category TEXT NOT NULL,
                click_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                ip_address TEXT,
                user_agent TEXT
            )
        ");
        
        // Table pour le cache des statuts
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS status_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                service_url TEXT UNIQUE NOT NULL,
                is_online BOOLEAN NOT NULL,
                response_time INTEGER,
                last_check DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Index pour optimiser les requêtes
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_usage_app_name ON usage_stats(app_name)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_usage_date ON usage_stats(click_date)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_status_url ON status_cache(service_url)");
        
        return true;
    } catch (PDOException $e) {
        error_log("Erreur lors de l'initialisation de la base de données: " . $e->getMessage());
        return false;
    }
}

function logUsage($appName, $appUrl, $category) {
    $pdo = getDatabase();
    if (!$pdo) return false;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO usage_stats (app_name, app_url, category, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        
        return $stmt->execute([$appName, $appUrl, $category, $ipAddress, $userAgent]);
    } catch (PDOException $e) {
        error_log("Erreur lors de l'enregistrement des statistiques: " . $e->getMessage());
        return false;
    }
}

function getUsageStats($period = '30 days') {
    $pdo = getDatabase();
    if (!$pdo) return [];
    
    try {
        // Statistiques par application
        $stmt = $pdo->prepare("
            SELECT 
                app_name,
                category,
                COUNT(*) as click_count,
                MAX(click_date) as last_used
            FROM usage_stats 
            WHERE click_date >= datetime('now', '-' || ? || '')
            GROUP BY app_name, category
            ORDER BY click_count DESC
        ");
        $stmt->execute([$period]);
        $appStats = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Statistiques par jour
        $stmt = $pdo->prepare("
            SELECT 
                DATE(click_date) as date,
                COUNT(*) as clicks
            FROM usage_stats 
            WHERE click_date >= datetime('now', '-' || ? || '')
            GROUP BY DATE(click_date)
            ORDER BY date DESC
        ");
        $stmt->execute([$period]);
        $dailyStats = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Statistiques par heure
        $stmt = $pdo->prepare("
            SELECT 
                strftime('%H', click_date) as hour,
                COUNT(*) as clicks
            FROM usage_stats 
            WHERE click_date >= datetime('now', '-7 days')
            GROUP BY strftime('%H', click_date)
            ORDER BY hour
        ");
        $stmt->execute();
        $hourlyStats = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return [
            'apps' => $appStats,
            'daily' => $dailyStats,
            'hourly' => $hourlyStats
        ];
    } catch (PDOException $e) {
        error_log("Erreur lors de la récupération des statistiques: " . $e->getMessage());
        return [];
    }
}

function updateStatusCache($serviceUrl, $isOnline, $responseTime = null) {
    $pdo = getDatabase();
    if (!$pdo) return false;
    
    try {
        $stmt = $pdo->prepare("
            INSERT OR REPLACE INTO status_cache (service_url, is_online, response_time, last_check) 
            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ");
        
        return $stmt->execute([$serviceUrl, $isOnline ? 1 : 0, $responseTime]);
    } catch (PDOException $e) {
        error_log("Erreur lors de la mise à jour du cache de statut: " . $e->getMessage());
        return false;
    }
}

function getStatusFromCache($serviceUrl) {
    $pdo = getDatabase();
    if (!$pdo) return null;
    
    try {
        $stmt = $pdo->prepare("
            SELECT is_online, response_time, last_check 
            FROM status_cache 
            WHERE service_url = ? 
            AND last_check > datetime('now', '-' || ? || ' seconds')
        ");
        $stmt->execute([$serviceUrl, STATUS_CACHE_TIME]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            return [
                'online' => (bool)$result['is_online'],
                'response_time' => $result['response_time'],
                'cached' => true
            ];
        }
        
        return null;
    } catch (PDOException $e) {
        error_log("Erreur lors de la récupération du cache de statut: " . $e->getMessage());
        return null;
    }
}
?>
