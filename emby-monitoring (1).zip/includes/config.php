<?php
// Configuration de la base de données
define('DB_PATH', __DIR__ . '/../data/dashboard.db');

// Configuration des timeouts pour la vérification de statut
define('STATUS_TIMEOUT', 5); // 5 secondes
define('STATUS_CACHE_TIME', 300); // 5 minutes

// Configuration générale
define('SITE_NAME', 'Marlo-Movie Dashboard');
define('SITE_VERSION', '2.0.0');

// Créer le dossier data s'il n'existe pas
$dataDir = dirname(DB_PATH);
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
}
?>
