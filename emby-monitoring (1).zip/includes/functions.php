<?php
function checkServiceStatus($url) {
    // Vérifier d'abord le cache
    $cached = getStatusFromCache($url);
    if ($cached) {
        return $cached;
    }
    
    $startTime = microtime(true);
    $isOnline = false;
    $responseTime = null;
    
    // Extraire l'host et le port de l'URL
    $parsedUrl = parse_url($url);
    $host = $parsedUrl['host'] ?? '';
    $port = $parsedUrl['port'] ?? ($parsedUrl['scheme'] === 'https' ? 443 : 80);
    
    if ($host) {
        // Utiliser fsockopen pour une vérification rapide
        $connection = @fsockopen($host, $port, $errno, $errstr, STATUS_TIMEOUT);
        if ($connection) {
            $isOnline = true;
            $responseTime = round((microtime(true) - $startTime) * 1000);
            fclose($connection);
        }
    }
    
    // Mettre à jour le cache
    updateStatusCache($url, $isOnline, $responseTime);
    
    return [
        'online' => $isOnline,
        'response_time' => $responseTime,
        'cached' => false
    ];
}

function formatBytes($size, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    for ($i = 0; $size > 1024 && $i < count($units) - 1; $i++) {
        $size /= 1024;
    }
    
    return round($size, $precision) . ' ' . $units[$i];
}

function getSystemInfo() {
    $info = [];
    
    // Informations PHP
    $info['php_version'] = PHP_VERSION;
    $info['server_software'] = $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown';
    
    // Utilisation mémoire
    $info['memory_usage'] = formatBytes(memory_get_usage(true));
    $info['memory_peak'] = formatBytes(memory_get_peak_usage(true));
    
    // Espace disque (si possible)
    if (function_exists('disk_free_space')) {
        $info['disk_free'] = formatBytes(disk_free_space('.'));
        $info['disk_total'] = formatBytes(disk_total_space('.'));
    }
    
    return $info;
}

function cleanOldStats($days = 90) {
    $pdo = getDatabase();
    if (!$pdo) return false;
    
    try {
        $stmt = $pdo->prepare("
            DELETE FROM usage_stats 
            WHERE click_date < datetime('now', '-' || ? || ' days')
        ");
        $stmt->execute([$days]);
        
        $stmt = $pdo->prepare("
            DELETE FROM status_cache 
            WHERE last_check < datetime('now', '-1 day')
        ");
        $stmt->execute();
        
        return true;
    } catch (PDOException $e) {
        error_log("Erreur lors du nettoyage des anciennes données: " . $e->getMessage());
        return false;
    }
}
?>
