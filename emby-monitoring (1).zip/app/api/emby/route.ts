import { type NextRequest, NextResponse } from "next/server"

const EMBY_URL = process.env.NEXT_PUBLIC_EMBY_URL || "http://74.210.253.59:8096"
const EMBY_API_KEY = process.env.NEXT_PUBLIC_EMBY_API_KEY || "05eddc445b564e45a38ead7bda7b67f3"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const endpoint = searchParams.get("endpoint")

  if (!endpoint) {
    return NextResponse.json({ error: "Endpoint manquant" }, { status: 400 })
  }

  try {
    const url = `${EMBY_URL}/emby${endpoint}`
    const finalUrl = url.includes("?") ? `${url}&api_key=${EMBY_API_KEY}` : `${url}?api_key=${EMBY_API_KEY}`

    console.log("Requête GET vers:", finalUrl)

    const response = await fetch(finalUrl, {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store, must-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      },
      cache: "no-store",
    })

    if (!response.ok) {
      throw new Error(`Erreur HTTP: ${response.status}`)
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error("Erreur API Emby:", error)
    return NextResponse.json(
      {
        error: "Erreur lors de la communication avec Emby",
        details: error instanceof Error ? error.message : "Erreur inconnue",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const endpoint = searchParams.get("endpoint")

  if (!endpoint) {
    return NextResponse.json({ error: "Endpoint manquant" }, { status: 400 })
  }

  try {
    let body = null
    try {
      body = await request.json()
    } catch (e) {
      // Si le corps est vide ou non-JSON, on continue sans body
    }

    const url = `${EMBY_URL}/emby${endpoint}`
    const finalUrl = url.includes("?") ? `${url}&api_key=${EMBY_API_KEY}` : `${url}?api_key=${EMBY_API_KEY}`

    console.log("Requête POST vers:", finalUrl, "Body:", body)

    const response = await fetch(finalUrl, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("Erreur réponse Emby:", errorText)
      throw new Error(`Erreur HTTP: ${response.status} - ${errorText}`)
    }

    let responseData
    try {
      responseData = await response.json()
    } catch (e) {
      responseData = { success: true, message: "Commande exécutée" }
    }

    return NextResponse.json(responseData)
  } catch (error) {
    console.error("Erreur API Emby POST:", error)
    return NextResponse.json(
      {
        error: "Erreur lors de la communication avec Emby",
        details: error instanceof Error ? error.message : "Erreur inconnue",
      },
      { status: 500 },
    )
  }
}
