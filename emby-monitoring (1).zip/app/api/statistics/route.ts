import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@vercel/postgres"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const period = searchParams.get("period") || "30"

    // Créer la table si elle n'existe pas
    await sql`
      CREATE TABLE IF NOT EXISTS usage_stats (
        id SERIAL PRIMARY KEY,
        app_name TEXT NOT NULL,
        app_url TEXT NOT NULL,
        category TEXT NOT NULL,
        click_date TIMESTAMP DEFAULT NOW(),
        ip_address TEXT,
        user_agent TEXT
      )
    `

    // Statistiques par application
    const appStats = await sql`
      SELECT 
        app_name,
        category,
        COUNT(*) as click_count,
        MAX(click_date) as last_used
      FROM usage_stats 
      WHERE click_date >= NOW() - INTERVAL '${period} days'
      GROUP BY app_name, category
      ORDER BY click_count DESC
    `

    // Statistiques quotidiennes
    const dailyStats = await sql`
      SELECT 
        DATE(click_date) as date,
        COUNT(*) as clicks
      FROM usage_stats 
      WHERE click_date >= NOW() - INTERVAL '${period} days'
      GROUP BY DATE(click_date)
      ORDER BY date DESC
    `

    // Statistiques par heure (7 derniers jours)
    const hourlyStats = await sql`
      SELECT 
        EXTRACT(HOUR FROM click_date) as hour,
        COUNT(*) as clicks
      FROM usage_stats 
      WHERE click_date >= NOW() - INTERVAL '7 days'
      GROUP BY EXTRACT(HOUR FROM click_date)
      ORDER BY hour
    `

    // Résumé
    const summary = await sql`
      SELECT 
        COUNT(*) as total_clicks,
        COUNT(DISTINCT app_name) as unique_apps,
        COUNT(DISTINCT DATE(click_date)) as active_days
      FROM usage_stats 
      WHERE click_date >= NOW() - INTERVAL '${period} days'
    `

    return NextResponse.json({
      apps: appStats.rows,
      daily: dailyStats.rows,
      hourly: hourlyStats.rows,
      summary: summary.rows[0] || { total_clicks: 0, unique_apps: 0, active_days: 0 },
    })
  } catch (error: any) {
    console.error("Erreur lors de la récupération des statistiques:", error)
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 })
  }
}
