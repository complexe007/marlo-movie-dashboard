import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@vercel/postgres"

export async function POST(request: NextRequest) {
  try {
    const { app_name, app_url, category } = await request.json()

    if (!app_name || !app_url || !category) {
      return NextResponse.json({ error: "Données manquantes" }, { status: 400 })
    }

    // Obtenir l'IP et User-Agent
    const ip = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown"
    const userAgent = request.headers.get("user-agent") || "unknown"

    // Insérer dans la base de données
    await sql`
      INSERT INTO usage_stats (app_name, app_url, category, ip_address, user_agent, click_date)
      VALUES (${app_name}, ${app_url}, ${category}, ${ip}, ${userAgent}, NOW())
    `

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erreur lors de l'enregistrement du clic:", error)
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 })
  }
}
