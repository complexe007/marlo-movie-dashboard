import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const url = searchParams.get("url")

  if (!url) {
    return NextResponse.json({ error: "URL manquante" }, { status: 400 })
  }

  try {
    const startTime = Date.now()

    // Utiliser fetch avec un timeout
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 secondes

    const response = await fetch(url, {
      method: "HEAD", // Plus rapide que GET
      signal: controller.signal,
      headers: {
        "User-Agent": "Marlo-Movie-Dashboard/1.0",
      },
    })

    clearTimeout(timeoutId)
    const responseTime = Date.now() - startTime

    return NextResponse.json({
      online: response.ok,
      response_time: responseTime,
      status_code: response.status,
    })
  } catch (error: any) {
    console.error("Erreur lors de la vérification du statut:", error.message)

    return NextResponse.json({
      online: false,
      error: error.name === "AbortError" ? "Timeout" : error.message,
    })
  }
}
