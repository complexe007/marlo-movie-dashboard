"use client"

import { useState, useEffect } from "react"
import { Search } from "lucide-react"
import { AppCard } from "@/components/AppCard"
import { StatusOverview } from "@/components/StatusOverview"
import { Navigation } from "@/components/Navigation"

// Configuration des applications (identique à votre PHP)
const apps = {
  medias: {
    name: "Médias",
    icon: "film",
    items: [
      {
        name: "Emby",
        url: "http://74.210.253.59:8096",
        logo: "https://emby.media/resources/Logo-light-transparent-286x118.png",
        color: "#52B54B",
        description: "Serveur média",
      },
      {
        name: "Radarr",
        url: "http://74.210.253.59:7878",
        logo: "https://raw.githubusercontent.com/Radarr/Radarr/develop/Logo/256.png",
        color: "#ffffff",
        description: "Gestion de films",
      },
      {
        name: "Sonarr",
        url: "http://74.210.253.59:8989",
        logo: "https://raw.githubusercontent.com/Sonarr/Sonarr/develop/Logo/256.png",
        color: "#ffffff",
        description: "Gestion de séries",
      },
      {
        name: "Prowlarr",
        url: "http://74.210.253.59:9696",
        logo: "https://raw.githubusercontent.com/Prowlarr/Prowlarr/develop/Logo/256.png",
        color: "#ffffff",
        description: "Gestion d'indexeurs",
      },
    ],
  },
  serveurs: {
    name: "Serveurs",
    icon: "server",
    items: [
      {
        name: "Portainer",
        url: "http://74.210.253.59:9000",
        logo: "https://cdn.worldvectorlogo.com/logos/portainer.svg",
        color: "#13BEF9",
        description: "Gestion Docker",
      },
      {
        name: "Transmission",
        url: "http://74.210.253.59:9091",
        logo: "https://upload.wikimedia.org/wikipedia/commons/6/6d/Transmission_icon.png",
        color: "#ffffff",
        description: "Client BitTorrent",
      },
      {
        name: "Synology",
        url: "http://74.210.253.59:5000",
        logo: "https://global.download.synology.com/download/Package/img/Docker/1.11.2-0270/thumb_256.png",
        color: "#ffffff",
        description: "NAS",
      },
      {
        name: "Tautulli",
        url: "http://74.210.253.59:8181",
        logo: "https://tautulli.com/images/logo-circle.png",
        color: "#ffffff",
        description: "Statistiques Plex",
      },
    ],
  },
  iptv: {
    name: "IPTV & TV",
    icon: "tv",
    items: [
      {
        name: "Edge",
        url: "http://login.edge.bz:2095/login.php?referrer=/reseller.php",
        icon: "tv",
        color: "#4CAF50",
        description: "Fournisseur IPTV",
      },
      {
        name: "Diablo",
        url: "http://e-billing.diablo-pro.com/login",
        icon: "tv",
        color: "#FF5722",
        description: "Fournisseur IPTV",
      },
      {
        name: "Raccoon",
        url: "http://raccoon.bz:2095/gDxTgDUM/",
        icon: "tv",
        color: "#607D8B",
        description: "Fournisseur IPTV",
      },
      {
        name: "Resotik",
        url: "https://tv.resotik.ca/revendeur/login?referrer=logout",
        icon: "tv",
        color: "#3F51B5",
        description: "Fournisseur IPTV",
      },
      {
        name: "Radio",
        url: "https://marlo-movie.com/media/",
        icon: "broadcast-tower",
        color: "#9C27B0",
        description: "Écouter la radio",
      },
      {
        name: "NeoStream",
        url: "https://marlo-movie.com/cooltv/",
        icon: "play-circle",
        color: "#2196F3",
        description: "Streaming TV",
      },
      {
        name: "TV Canada",
        url: "https://marlo-movie.com/canada/",
        logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Flag_of_Canada_%28Pantone%29.svg/1200px-Flag_of_Canada_%28Pantone%29.svg.png",
        color: "#F44336",
        description: "TV canadienne",
      },
      {
        name: "TV Canada 2",
        url: "https://marlo-movie.com/iptv/",
        logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Flag_of_Canada_%28Pantone%29.svg/1200px-Flag_of_Canada_%28Pantone%29.svg.png",
        color: "#F44336",
        description: "TV canadienne",
      },
    ],
  },
  sites_pratiques: {
    name: "Sites pratiques",
    icon: "globe",
    items: [
      {
        name: "TMDB",
        url: "https://www.themoviedb.org/",
        logo: "https://www.themoviedb.org/assets/2/v4/logos/v2/blue_square_2-d537fb228cf3ded904ef09b136fe3fec72548ebc1fea3fbbd1ad9e36364db38b.svg",
        color: "#01D277",
        description: "Base de données de films",
      },
      {
        name: "Installer TiviMate",
        url: "https://sosreparation.net/app/",
        icon: "download",
        color: "#FF9800",
        description: "Guide d'installation",
      },
      {
        name: "TiviMate Code",
        url: "https://iptv-qc.com/tivimate-firestick-firetv/",
        icon: "key",
        color: "#FF9800",
        description: "Codes d'activation",
      },
      {
        name: "Rutorrent",
        url: "https://complexe.dark.seedhost.eu/rutorrent/",
        logo: "https://github.com/Novik/ruTorrent/raw/master/images/logo.png",
        color: "#388E3C",
        description: "Client torrent",
      },
      {
        name: "Proton Mail",
        url: "https://account.proton.me/login",
        logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-SHSsZh2liDqTg651joCL0pBVz2pfzp.png",
        color: "#8E24AA",
        description: "Email sécurisé",
      },
      {
        name: "SmartTube",
        url: "https://troypoint.com/smarttube/",
        logo: "https://github.com/yuliskov/SmartTubeNext/raw/master/smarttubetv/src/main/res/mipmap-xxxhdpi/ic_launcher.png",
        color: "#FF0000",
        description: "Alternative YouTube",
      },
      {
        name: "Ferme Lufa",
        url: "https://montreal.lufa.com/fr/marche",
        logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-AUBj9YIMcoDbxVXd9XMq8Mqyyt4NUb.png",
        color: "#4CAF50",
        description: "Produits fermiers",
      },
      {
        name: "Google Traduction",
        url: "http://translate.google.com/",
        logo: "https://upload.wikimedia.org/wikipedia/commons/d/db/Google_Translate_Icon.png",
        color: "#4285F4",
        description: "Traduction en ligne",
      },
      {
        name: "Mes domaines",
        url: "https://cp.zoneedit.com/login.php/",
        icon: "globe",
        color: "#607D8B",
        description: "Gestion de domaines",
      },
      {
        name: "cPanel",
        url: "https://cpanel3.easyweb.com:2083/",
        logo: "https://cpanel.net/wp-content/themes/cPbase/assets/img/logos/cp-logo.svg",
        color: "#FF6C2C",
        description: "Gestion d'hébergement",
      },
    ],
  },
  banque: {
    name: "Banque & Paiements",
    icon: "credit-card",
    items: [
      {
        name: "PayPal",
        url: "https://www.paypal.com/signin",
        logo: "https://www.paypalobjects.com/webstatic/icon/pp258.png",
        color: "#003087",
        description: "Paiements en ligne",
      },
      {
        name: "Fizz",
        url: "https://fizz.ca/fr",
        logo: "https://styles.redditmedia.com/t5_pfbj4/styles/communityIcon_efu9qf2ekqp21.jpg?format=pjpg&s=f262fbccd93dc6cae3032fd85ae873f062a6cd6d",
        color: "#00884a",
        description: "Services mobile",
      },
      {
        name: "Telus",
        url: "https://www.telus.com/",
        logo: "https://www.telus.com/content/dam/telus-images/brand/telus-logo.svg",
        color: "#6ad400",
        description: "Services mobile",
      },
      {
        name: "RBC Banque",
        url: "https://www.rbcbanqueroyale.com/fr/",
        logo: "https://www.rbcroyalbank.com/dvl/v1.0/assets/images/logos/rbc-logo-shield.svg",
        color: "#0051a5",
        description: "Services bancaires",
      },
      {
        name: "Banque EQ",
        url: "https://secure.eqbank.ca/login",
        logo: "https://secure.eqbank.ca/assets/images/fr/eq-logo-small.png",
        color: "#FFFF00",
        description: "Paiements en ligne",
      },
    ],
  },
  outils: {
    name: "Outils",
    icon: "tools",
    items: [
      {
        name: "Speedtest",
        url: "https://speedtest.net",
        logo: "https://www.speedtest.net/s/images/ookla-logo-black-text.svg",
        color: "#141526",
        description: "Test de vitesse",
      },
      {
        name: "IP Checker",
        url: "https://whatismyipaddress.com",
        icon: "network-wired",
        color: "#4CAF50",
        description: "Vérification IP",
      },
      {
        name: "DNS Checker",
        url: "https://dnschecker.org",
        icon: "sitemap",
        color: "#2196F3",
        description: "Vérification DNS",
      },
      {
        name: "Down Detector",
        url: "https://downdetector.com",
        icon: "exclamation-triangle",
        color: "#FF9800",
        description: "Statut des services",
      },
    ],
  },
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("medias")
  const [searchTerm, setSearchTerm] = useState("")
  const [serviceStatuses, setServiceStatuses] = useState<Record<string, any>>({})

  // Charger les statuts des services
  useEffect(() => {
    const loadStatuses = async () => {
      const currentApps = apps[activeTab as keyof typeof apps]?.items || []
      const statuses: Record<string, any> = {}

      for (const app of currentApps) {
        try {
          const response = await fetch(`/api/check-status?url=${encodeURIComponent(app.url)}`)
          const status = await response.json()
          statuses[app.name] = status
        } catch (error) {
          statuses[app.name] = { online: false, error: true }
        }
      }

      setServiceStatuses(statuses)
    }

    loadStatuses()

    // Mise à jour automatique toutes les minutes
    const interval = setInterval(loadStatuses, 60000)
    return () => clearInterval(interval)
  }, [activeTab])

  // Filtrer les applications selon la recherche
  const currentApps = apps[activeTab as keyof typeof apps]?.items || []
  const filteredApps = currentApps.filter(
    (app) =>
      app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAppClick = async (app: any) => {
    // Enregistrer le clic
    try {
      await fetch("/api/track-click", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          app_name: app.name,
          app_url: app.url,
          category: activeTab,
        }),
      })
    } catch (error) {
      console.warn("Erreur lors de l'enregistrement du clic:", error)
    }

    // Ouvrir l'application
    window.open(app.url, "_blank")
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-b from-red-900 to-yellow-600 p-4 border-b-2 border-yellow-600">
        <h1 className="text-2xl md:text-3xl font-bold text-center uppercase tracking-wider flex items-center justify-center gap-3">
          <i className="fas fa-film text-yellow-600"></i>
          Marlo-Movie Dashboard
        </h1>
      </header>

      {/* Navigation */}
      <Navigation apps={apps} activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Content */}
      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        {/* Search */}
        <div className="relative mb-6">
          <input
            type="text"
            placeholder="Rechercher une application..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-3 pr-12 bg-gray-800 border border-yellow-600/30 rounded-full text-white placeholder-gray-400 focus:outline-none focus:border-yellow-600 focus:ring-2 focus:ring-yellow-600/20"
          />
          <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-yellow-600 w-5 h-5" />
        </div>

        {/* Status Overview */}
        <StatusOverview statuses={serviceStatuses} totalApps={currentApps.length} />

        {/* Apps Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filteredApps.map((app) => (
            <AppCard key={app.name} app={app} status={serviceStatuses[app.name]} onClick={() => handleAppClick(app)} />
          ))}
        </div>

        {filteredApps.length === 0 && searchTerm && (
          <div className="text-center py-12">
            <Search className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">Aucune application trouvée pour "{searchTerm}"</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-t from-red-900 to-yellow-600 p-4 border-t-2 border-yellow-600 text-center">
        <p>&copy; {new Date().getFullYear()} Marlo-Movie Dashboard</p>
      </footer>
    </div>
  )
}
