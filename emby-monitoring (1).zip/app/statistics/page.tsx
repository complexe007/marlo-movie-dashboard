"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, TrendingUp, Users, MousePointer, Calendar } from "lucide-react"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"
import { Line, Bar } from "react-chartjs-2"

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend)

interface StatisticsData {
  apps: Array<{
    app_name: string
    category: string
    click_count: number
    last_used: string
  }>
  daily: Array<{
    date: string
    clicks: number
  }>
  hourly: Array<{
    hour: string
    clicks: number
  }>
  summary: {
    total_clicks: number
    unique_apps: number
    active_days: number
  }
}

export default function StatisticsPage() {
  const [period, setPeriod] = useState("30")
  const [data, setData] = useState<StatisticsData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      setLoading(true)
      try {
        const response = await fetch(`/api/statistics?period=${period}`)
        const statsData = await response.json()
        setData(statsData)
      } catch (error) {
        console.error("Erreur lors du chargement des statistiques:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [period])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-600 mx-auto mb-4"></div>
          <p>Chargement des statistiques...</p>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-400">Erreur lors du chargement des statistiques</p>
          <Link href="/" className="text-yellow-600 hover:underline mt-2 inline-block">
            Retour au dashboard
          </Link>
        </div>
      </div>
    )
  }

  // Préparer les données pour les graphiques
  const dailyChartData = {
    labels: data.daily.map((d) => new Date(d.date).toLocaleDateString("fr-FR")),
    datasets: [
      {
        label: "Clics par jour",
        data: data.daily.map((d) => d.clicks),
        borderColor: "#b8860b",
        backgroundColor: "rgba(184, 134, 11, 0.1)",
        tension: 0.4,
      },
    ],
  }

  const hourlyChartData = {
    labels: Array.from({ length: 24 }, (_, i) => `${i}h`),
    datasets: [
      {
        label: "Clics par heure",
        data: Array.from({ length: 24 }, (_, i) => {
          const hourData = data.hourly.find((h) => Number.parseInt(h.hour) === i)
          return hourData ? hourData.clicks : 0
        }),
        backgroundColor: "rgba(184, 134, 11, 0.7)",
        borderColor: "#b8860b",
        borderWidth: 1,
      },
    ],
  }

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        labels: {
          color: "#f5f5f5",
        },
      },
    },
    scales: {
      x: {
        ticks: { color: "#f5f5f5" },
        grid: { color: "rgba(245, 245, 245, 0.1)" },
      },
      y: {
        ticks: { color: "#f5f5f5" },
        grid: { color: "rgba(245, 245, 245, 0.1)" },
      },
    },
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gradient-to-b from-red-900 to-yellow-600 p-4 border-b-2 border-yellow-600">
        <div className="flex items-center gap-4">
          <Link href="/" className="text-white hover:text-yellow-200 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-2xl md:text-3xl font-bold uppercase tracking-wider flex items-center gap-3">
            <TrendingUp className="text-yellow-600" />
            Statistiques d'utilisation
          </h1>
        </div>
      </header>

      {/* Period Navigation */}
      <nav className="bg-gray-800 p-4 border-b border-yellow-600/30">
        <div className="flex gap-2 justify-center">
          {[
            { value: "7", label: "7 jours" },
            { value: "30", label: "30 jours" },
            { value: "90", label: "90 jours" },
          ].map(({ value, label }) => (
            <button
              key={value}
              onClick={() => setPeriod(value)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                period === value ? "bg-yellow-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </nav>

      <main className="p-6 max-w-7xl mx-auto">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-gray-800 border border-yellow-600/30 rounded-lg p-6 flex items-center gap-4">
            <MousePointer className="w-8 h-8 text-yellow-600" />
            <div>
              <h3 className="text-2xl font-bold">{data.summary.total_clicks}</h3>
              <p className="text-gray-400">Clics totaux</p>
            </div>
          </div>
          <div className="bg-gray-800 border border-yellow-600/30 rounded-lg p-6 flex items-center gap-4">
            <Users className="w-8 h-8 text-yellow-600" />
            <div>
              <h3 className="text-2xl font-bold">{data.summary.unique_apps}</h3>
              <p className="text-gray-400">Applications utilisées</p>
            </div>
          </div>
          <div className="bg-gray-800 border border-yellow-600/30 rounded-lg p-6 flex items-center gap-4">
            <Calendar className="w-8 h-8 text-yellow-600" />
            <div>
              <h3 className="text-2xl font-bold">{data.summary.active_days}</h3>
              <p className="text-gray-400">Jours d'activité</p>
            </div>
          </div>
        </div>

        {/* Top Applications */}
        <div className="bg-gray-800 border border-yellow-600/30 rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
            <TrendingUp className="text-yellow-600" />
            Applications les plus utilisées
          </h2>
          <div className="space-y-3">
            {data.apps.slice(0, 10).map((app, index) => (
              <div
                key={`${app.app_name}-${app.category}`}
                className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <span className="text-yellow-600 font-bold w-8">#{index + 1}</span>
                  <div>
                    <span className="font-medium">{app.app_name}</span>
                    <span className="text-gray-400 text-sm ml-2 uppercase">{app.category}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-green-400 font-bold">{app.click_count} clics</div>
                  <div className="text-gray-400 text-xs">{new Date(app.last_used).toLocaleDateString("fr-FR")}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Daily Activity */}
          <div className="bg-gray-800 border border-yellow-600/30 rounded-lg p-6">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Calendar className="text-yellow-600" />
              Activité quotidienne
            </h2>
            <Line data={dailyChartData} options={chartOptions} />
          </div>

          {/* Hourly Activity */}
          <div className="bg-gray-800 border border-yellow-600/30 rounded-lg p-6">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <TrendingUp className="text-yellow-600" />
              Activité par heure (7 derniers jours)
            </h2>
            <Bar data={hourlyChartData} options={chartOptions} />
          </div>
        </div>
      </main>
    </div>
  )
}
